package com.apptus;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;

/**
 * Created by prasanth on 31/3/16.
 */
public class CoinChange {


    ArrayList<Coin> coins;

    public CoinChange(){
        coins = new ArrayList<Coin>();
    }

    public void add(Coin c){
        coins.add(c);
    }

    public HashMap<Coin,Integer> getCoinsForChange( int amount ){
        ArrayList<Coin> smallCoins = getAllCoinValulesLessThanAmount(coins,amount);
        return getCoinsForAmount(smallCoins,amount);
    }


    private HashMap<Coin,Integer> getCoinsForAmount( ArrayList<Coin> smallCoins , int amount){
           //logic to find the change
            return new HashMap<Coin,Integer>();
    }

    private ArrayList<Coin> getAllCoinValulesLessThanAmount(ArrayList<Coin> coins, int amount){
        ArrayList<Coin> smallCoins = new ArrayList<Coin>();
        for(Coin c:coins){
            if( c.getCount() > 0 && amount >= c.getValue() ){
                smallCoins.add(c);
            }
        }
        return smallCoins;
    }






}
